class List {
	
	public List() {
	}
	
	static double totalPrice = 0;
	
	public void coffeeList(char coffeeType){
		switch (coffeeType) {
		case 'A': System.out.println("     -Espresso" + ": 4.50");
		totalPrice = totalPrice + 4.50;
			break;
		case 'B': System.out.println("     -Double Espresso" + ": 3.90");
		totalPrice = totalPrice + 3.90;
			break;
		case 'C': System.out.println("     -Short Macchiato" + ": 2.10");
		totalPrice = totalPrice + 2.10;
			break;
		case 'D': System.out.println("     -Long Macchiato" + ": 4.50");
		totalPrice = totalPrice + 4.50;
			break;
		case 'E': System.out.println("     -Ristretto" + ": 6.30");
		totalPrice = totalPrice + 6.30;
			break;
		case 'F': System.out.println("     -Long Black" + ": 3.90");
		totalPrice = totalPrice + 3.90;
			break;
		case 'G': System.out.println("     -Café Latte" + ": 2.90");
		totalPrice = totalPrice + 2.90;
			break;
		case 'H': System.out.println("     -Flat White" + ": 2.20");
		totalPrice = totalPrice + 2.20;
			break;
		case 'I': System.out.println("     -Piccolo Latte" + ": 2.10");
		totalPrice = totalPrice + 2.10;
			break;
		case 'J': System.out.println("     -Mocha" + ": 3.10");
		totalPrice = totalPrice + 3.10;
			break;
		case 'K': System.out.println("     -Affogato" + ": 8.90");
		totalPrice = totalPrice + 8.90;
			break;
		default: System.out.print(" ");
			
		}
	}

	public void cakeOrder(int num , String cakeType) {
		System.out.print("   -" + num + " ");
		System.out.print(cakeType + ": " + num * 2.50);
		totalPrice = totalPrice + num * 2.50;
	}
	
	
	public static void main(String[] args) {
		
	}
}