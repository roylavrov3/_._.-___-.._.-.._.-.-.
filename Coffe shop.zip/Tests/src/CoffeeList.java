//import java.util.Scanner;

class Cafe extends List{
	
	public Cafe() {
	}
	
	
	public void peopleNum(int num) {
		System.out.println("   A table for " + num);
		System.out.println("---------------------------------");;
	}
	
	public void numOfDrinks(int num ){
		System.out.println("   -" + num + " cups of coffee:");
	}
	
	//Not used
 	public void numOfPieces(int num) {
		System.out.print("   -" + num + " pieces of cake" + num * 2.50);
		totalPrice = totalPrice + num * 2.50;
	}
	
	public void shareCake(char answer) {
		if (answer == 'Y') {
			System.out.println(" -A whole cake");
		}else {
			System.out.println(" -No whole cake");
		}
		
		
		
	}
	
	public void sugar(int num) {
		System.out.println(" -" + num + " cubes of sugar");
	}
	
	//[][][][][][][][][][][][][][][][][][][][[][][][][][][][][][][][[][][][][][][][][][]
	//[][][][][][][][][][][][][][][][][][][][[][][][][][][][][][][][[][][][][][][][][][]
	//[][][][][][][][][][][][][][][][][][][][[][][][][][][][][][][][[][][][][][][][][][]
	
	
	public static void main(String[] args) {
		//Scanner scan = new Scanner (System.in);
		
		Cafe myOrder = new Cafe();
		//Settings:
		System.out.println("--Your receipt:");
		myOrder.peopleNum(3); //Number of people in the table	
		myOrder.numOfDrinks(4); //Number of drinks	
		myOrder.coffeeList('A'); //Coffee list1
		myOrder.coffeeList('C'); //Coffee list2
		myOrder.coffeeList('B'); //Coffee list3
		myOrder.coffeeList('D'); //Coffee list4
		myOrder.coffeeList('X'); //Coffee list5
		myOrder.sugar(1); //Cubes of sugar
		myOrder.cakeOrder(4,"chocoalte cake"); //Pieces of cake	
		myOrder.shareCake('Y'); // Share cake?
		
		
		System.out.println("-------------------------------");
		System.out.println("    TOTAL: " + totalPrice); //Price
		
		/*int user_input_number = scan.nextInt();
		System.out.print("Payed in credit: ");
		System.out.print(user_input_number);*/
		
		
	}
}